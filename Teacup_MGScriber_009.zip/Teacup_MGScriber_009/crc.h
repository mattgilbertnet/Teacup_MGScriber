#ifndef	_CRC_H
#define	_CRC_H

#include	<stdint.h>

uint16_t	crc_block(void *data, uint16_t len);

#endif	/* _CRC_H */
