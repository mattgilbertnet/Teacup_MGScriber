#ifndef	_HOME_H
#define _HOME_H

void home(void);

void home_x_negative(void);
void home_x_positive(void);
void home_y_negative(void);
void home_y_positive(void);
void home_z_negative(void);
void home_z_positive(void);

#endif	/* _HOME_H */
