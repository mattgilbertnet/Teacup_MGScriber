
// Configuration for controller board.
#include "config/board.mgscriber-uno-0002.h"

// Configuration for printer board.
#include "config/printer.mgscriber.h"
