#ifndef  _SCRIBER_H
#define _SCRIBER_H

#include  "dda.h"

void dremel_on(void);
void dremel_off(void);
#endif  /* _SCRIBER_H */
